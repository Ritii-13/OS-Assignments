# MeMS - Memory Management System

MeMS (Memory Management System) is a custom memory management system implemented in C, designed to efficiently manage memory allocation and deallocation. It provides a flexible way to allocate, deallocate, and manage memory segments using `mmap` and a custom data structure.

## Table of Contents

- [Introduction](#introduction)
- [Running the Code](#running-the-code)
- [Usage](#usage)
- [Functions](#functions)

## Introduction

The MeMS system is designed to:

- Efficiently allocate and deallocate memory segments.
- Keep track of the allocated memory segments and free segments.
- Provide statistics about memory usage and free memory.

## Running the Code

$  make

$ ./example

## Usage

MeMS provides a set of functions that allow you to allocate, deallocate, and manage memory segments in your C programs. To use MeMS, you can include the "mems.h" header in your code and use the provided functions like we have done in example.c

## Functions

MeMS provides the following functions:

- void mems_init(): Initializes the MeMS system.
- void mems_finish(): Finalizes the MeMS system and releases all allocated memory.
- void* mems_malloc(size_t size): Allocates memory of the specified size.
- void mems_free(void* v_ptr): Frees the memory pointed to by the MeMS virtual address.
- void mems_print_stats(): Prints statistics about the MeMS system's memory usage.
